﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace FinalProject
{
    public partial class Form1 : Form
    {
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void showImage(string filename);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void showGrayscaleImage(string filename);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myRotate(string filename, double angle);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myMirrorLeftandRight(string filename);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myMirrorUpandDown(string filename);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myMirroringUpDownLeftandRight(string filename);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myZoom(string filename, double fx, double fy);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myShear(string filename, double Sh, double Sv);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myFlip(string filename, double x, double y);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myVague(string filename, int maskSize);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myNegative(string filename);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myLog(string filename, double L);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myPowerLaw(string filename, double PowerGamma);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void mySaturation(string filename, double pos);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myLaplace(string filename, int x);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myConvertScaleAbs(string filename, double alpha, double beta);
        [DllImport("imgFunc.dll", CallingConvention = CallingConvention.Cdecl,
                    CharSet = CharSet.Ansi)]
        static extern void myCloseAllWindows();

        public Form1()
        {
            InitializeComponent();
        }

        private void button_selectFile_Click(object sender, EventArgs e) //選擇檔案
        {
            OpenFileDialog ofDialog = new OpenFileDialog();
            if (ofDialog.ShowDialog() == DialogResult.OK)
            {
                textBox_fileName.Text = ofDialog.FileName;
            }
        }

        private void button_displayImage_Click(object sender, EventArgs e) //顯示彩色影像
        {
            showImage(textBox_fileName.Text);
        }

        private void button_grayscaleImage_Click(object sender, EventArgs e) //顯示灰階影像
        {
            showGrayscaleImage(textBox_fileName.Text);
        }

        private void button_Rotate_Click(object sender, EventArgs e) //旋轉按鈕
        {
            label_angle.Text = "0°";
            trackBar_angle.Value = 0;
            myRotate(textBox_fileName.Text, 0);
        }

        private void trackBar_rotate_Scroll(object sender, EventArgs e) //旋轉
        {
            label_angle.Text = Convert.ToString(trackBar_angle.Value) + "°";
            myRotate(textBox_fileName.Text, trackBar_angle.Value);
        }

        private void button_MirrorLeftandRight_Click(object sender, EventArgs e) //水平翻轉
        {
            myMirrorLeftandRight(textBox_fileName.Text);
        }

        private void button_MirrorUpandDown_Click(object sender, EventArgs e) //垂直翻轉
        {
            myMirrorUpandDown(textBox_fileName.Text);
        }

        private void button_MirroringUpDownLeftandRight_Click(object sender, EventArgs e) //平直翻轉
        {
            myMirroringUpDownLeftandRight(textBox_fileName.Text);
        }

        private void button_Zoom_Click(object sender, EventArgs e) //縮放按鈕
        {
            label_x.Text = "X × 1";
            label_y.Text = "Y × 1";
            trackBar_x.Value = 100;
            trackBar_y.Value = 100;
            myZoom(textBox_fileName.Text, 1, 1);
        }

        private void trackBar_x_Scroll(object sender, EventArgs e) //縮放X
        {
            label_x.Text = "X × " + (trackBar_x.Value / 100.0).ToString();
            myZoom(textBox_fileName.Text, trackBar_x.Value / 100.0, trackBar_y.Value / 100.0);
        }

        private void trackBar_Y_Scroll(object sender, EventArgs e) //縮放Y
        {
            label_y.Text = "Y × " + (trackBar_y.Value / 100.0).ToString();
            myZoom(textBox_fileName.Text, trackBar_x.Value / 100.0, trackBar_y.Value / 100.0);
        }

        private void button_Shear_Click(object sender, EventArgs e) //剪形按鈕
        {
            label_ShearH.Text = "Sh = 0";
            label_ShearV.Text = "Sv = 0";
            trackBar_ShearH.Value = 0;
            trackBar_ShearV.Value = 0;
            myShear(textBox_fileName.Text, 0, 0);
        }

        private void trackBar_ShearH_Scroll(object sender, EventArgs e) //水平剪形
        {
            label_ShearH.Text = "Sh = " + (trackBar_ShearH.Value / 100.0).ToString();
            myShear(textBox_fileName.Text, trackBar_ShearH.Value / 100.0, trackBar_ShearV.Value / 100.0);
        }

        private void trackBar_ShearV_Scroll(object sender, EventArgs e) //垂直剪形
        {
            label_ShearV.Text = "Sv = " + (trackBar_ShearV.Value / 100.0).ToString();
            myShear(textBox_fileName.Text, trackBar_ShearH.Value / 100.0, trackBar_ShearV.Value / 100.0);
        }

        private void button_Flip_Click(object sender, EventArgs e) //翻轉按鈕
        {
            label_FlipX.Text = "X × 1";
            label_FlipY.Text = "Y × 1";
            trackBar_FlipX.Value = 100;
            trackBar_FlipY.Value = 100;
            myFlip(textBox_fileName.Text, 1, 1);
        }

        private void trackBar_FlipX_Scroll(object sender, EventArgs e) //水平翻轉
        {
            label_FlipX.Text = "X × " + (trackBar_FlipX.Value / 100.0).ToString();
            myFlip(textBox_fileName.Text, trackBar_FlipX.Value / 100.0, trackBar_FlipY.Value / 100.0);
        }

        private void trackBar_FlipY_Scroll(object sender, EventArgs e) //垂直翻轉
        {
            label_FlipY.Text = "Y × " + (trackBar_FlipY.Value / 100.0).ToString();
            myFlip(textBox_fileName.Text, trackBar_FlipX.Value / 100.0, trackBar_FlipY.Value / 100.0);
        }

        private void button_Vague_Click(object sender, EventArgs e)//模糊按鈕
        {
            label_Vague.Text = "MS = 1";
            trackBar_Vague.Value = 1;
            myVague(textBox_fileName.Text, 1);
        }

        private void trackBar_Vague_Scroll(object sender, EventArgs e) //模糊
        {
            label_Vague.Text = "MS = " + trackBar_Vague.Value.ToString();
            myVague(textBox_fileName.Text, trackBar_Vague.Value);
        }

        private void button_Negative_Click(object sender, EventArgs e) //負片
        {
            myNegative(textBox_fileName.Text);
        }

        private void button_Log_Click(object sender, EventArgs e) //Log亮度按鈕
        {
            label_Log.Text = "Log = 1";
            trackBar_Log.Value = 100;
            myLog(textBox_fileName.Text, 1);
        }

        private void trackBar_Log_Scroll(object sender, EventArgs e) //Log亮度
        {
            label_Log.Text = "Log = " + (trackBar_Log.Value / 100.0).ToString();
            myLog(textBox_fileName.Text, trackBar_Log.Value / 100.0);
        }

        private void button_PowerLaw_Click(object sender, EventArgs e) //PowerLaw亮度按鈕
        {
            label_PowerGamma.Text = "γ = 1";
            trackBar_PowerLaw.Value = 100;
            myPowerLaw(textBox_fileName.Text, 1);
        }

        private void trackBar_PowerLaw_Scroll(object sender, EventArgs e) //PowerLaw亮度
        {
            label_PowerGamma.Text = "γ = " + (trackBar_PowerLaw.Value / 100.0).ToString();
            myPowerLaw(textBox_fileName.Text, trackBar_PowerLaw.Value / 100.0);
        }

        private void button_Saturation_Click(object sender, EventArgs e) //飽和度按鈕
        {
            label_Saturation.Text = "Pos = 1";
            trackBar_Saturation.Value = 100;
            mySaturation(textBox_fileName.Text, 1);
        }

        private void trackBar_Saturation_Scroll(object sender, EventArgs e) //飽和度
        {
            label_Saturation.Text = "Pos = " + (trackBar_Saturation.Value / 100.0).ToString();
            mySaturation(textBox_fileName.Text, trackBar_Saturation.Value / 100.0);
        }

        private void button_Laplace_Click(object sender, EventArgs e)//銳利度按鈕(Laplace卷積)
        {
            label_Laplace.Text = "X = 0";
            trackBar_Laplace.Value = 0;
            myLaplace(textBox_fileName.Text, 0);
        }

        private void trackBar_Laplace_Scroll(object sender, EventArgs e) //銳利度(Laplace卷積)
        {
            label_Laplace.Text = "X = " + trackBar_Laplace.Value;
            myLaplace(textBox_fileName.Text, trackBar_Laplace.Value);
        }

        private void button_ConvertScaleAbs_Click(object sender, EventArgs e) //線性亮度按鈕
        {
            label_alpha.Text = "α = 1";
            label_beta.Text = "β = 0";
            trackBar_alpha.Value = 100;
            trackBar_beta.Value = 0;
            myConvertScaleAbs(textBox_fileName.Text, 1, 0);
        }

        private void trackBar_alpha_Scroll(object sender, EventArgs e) //線性亮度alpha
        {
            label_alpha.Text = "α = " + trackBar_alpha.Value / 100.0;
            myConvertScaleAbs(textBox_fileName.Text, trackBar_alpha.Value / 100.0, trackBar_beta.Value);
        }

        private void trackBar_beta_Scroll(object sender, EventArgs e) //線性亮度beta
        {
            label_beta.Text = "β = " + trackBar_beta.Value;
            myConvertScaleAbs(textBox_fileName.Text, trackBar_alpha.Value / 100.0, trackBar_beta.Value);
        }

        private void button_CloseAllWindows_Click(object sender, EventArgs e) //關閉所有視窗
        {
            myCloseAllWindows();
        }
    }
}