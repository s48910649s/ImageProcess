﻿
namespace FinalProject
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.selectFile = new System.Windows.Forms.Button();
            this.label_fileName = new System.Windows.Forms.Label();
            this.textBox_fileName = new System.Windows.Forms.TextBox();
            this.displayImage = new System.Windows.Forms.Button();
            this.trackBar_angle = new System.Windows.Forms.TrackBar();
            this.label_angle = new System.Windows.Forms.Label();
            this.button_MirrorLeftandRight = new System.Windows.Forms.Button();
            this.button_MirrorUpandDown = new System.Windows.Forms.Button();
            this.button_MirroringUpDownLeftandRight = new System.Windows.Forms.Button();
            this.trackBar_x = new System.Windows.Forms.TrackBar();
            this.label_x = new System.Windows.Forms.Label();
            this.label_y = new System.Windows.Forms.Label();
            this.trackBar_y = new System.Windows.Forms.TrackBar();
            this.trackBar_ShearH = new System.Windows.Forms.TrackBar();
            this.trackBar_ShearV = new System.Windows.Forms.TrackBar();
            this.label_ShearH = new System.Windows.Forms.Label();
            this.label_ShearV = new System.Windows.Forms.Label();
            this.trackBar_FlipX = new System.Windows.Forms.TrackBar();
            this.trackBar_FlipY = new System.Windows.Forms.TrackBar();
            this.label_FlipX = new System.Windows.Forms.Label();
            this.label_FlipY = new System.Windows.Forms.Label();
            this.button_grayscaleImage = new System.Windows.Forms.Button();
            this.trackBar_Vague = new System.Windows.Forms.TrackBar();
            this.label_Vague = new System.Windows.Forms.Label();
            this.button_Negative = new System.Windows.Forms.Button();
            this.trackBar_Log = new System.Windows.Forms.TrackBar();
            this.label_Log = new System.Windows.Forms.Label();
            this.trackBar_PowerLaw = new System.Windows.Forms.TrackBar();
            this.label_PowerGamma = new System.Windows.Forms.Label();
            this.button_Rotate = new System.Windows.Forms.Button();
            this.button_Zoom = new System.Windows.Forms.Button();
            this.button_Shear = new System.Windows.Forms.Button();
            this.button_Flip = new System.Windows.Forms.Button();
            this.button_Vague = new System.Windows.Forms.Button();
            this.button_Log = new System.Windows.Forms.Button();
            this.button_PowerLaw = new System.Windows.Forms.Button();
            this.trackBar_Saturation = new System.Windows.Forms.TrackBar();
            this.label_Saturation = new System.Windows.Forms.Label();
            this.button_Saturation = new System.Windows.Forms.Button();
            this.button_CloseAllWindows = new System.Windows.Forms.Button();
            this.trackBar_Laplace = new System.Windows.Forms.TrackBar();
            this.label_Laplace = new System.Windows.Forms.Label();
            this.button_Laplace = new System.Windows.Forms.Button();
            this.trackBar_alpha = new System.Windows.Forms.TrackBar();
            this.trackBar_beta = new System.Windows.Forms.TrackBar();
            this.label_alpha = new System.Windows.Forms.Label();
            this.label_beta = new System.Windows.Forms.Label();
            this.button_ConvertScaleAbs = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_angle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_ShearH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_ShearV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_FlipX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_FlipY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Vague)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Log)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_PowerLaw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Saturation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Laplace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_alpha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_beta)).BeginInit();
            this.SuspendLayout();
            // 
            // selectFile
            // 
            this.selectFile.Location = new System.Drawing.Point(481, 7);
            this.selectFile.Name = "selectFile";
            this.selectFile.Size = new System.Drawing.Size(94, 29);
            this.selectFile.TabIndex = 3;
            this.selectFile.Text = "選擇檔案";
            this.selectFile.UseVisualStyleBackColor = true;
            this.selectFile.Click += new System.EventHandler(this.button_selectFile_Click);
            // 
            // label_fileName
            // 
            this.label_fileName.AutoSize = true;
            this.label_fileName.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_fileName.Location = new System.Drawing.Point(12, 9);
            this.label_fileName.Name = "label_fileName";
            this.label_fileName.Size = new System.Drawing.Size(100, 24);
            this.label_fileName.TabIndex = 4;
            this.label_fileName.Text = "目前檔案 : ";
            // 
            // textBox_fileName
            // 
            this.textBox_fileName.Location = new System.Drawing.Point(108, 7);
            this.textBox_fileName.Name = "textBox_fileName";
            this.textBox_fileName.Size = new System.Drawing.Size(367, 29);
            this.textBox_fileName.TabIndex = 6;
            // 
            // displayImage
            // 
            this.displayImage.Location = new System.Drawing.Point(581, 7);
            this.displayImage.Name = "displayImage";
            this.displayImage.Size = new System.Drawing.Size(94, 29);
            this.displayImage.TabIndex = 7;
            this.displayImage.Text = "顯示";
            this.displayImage.Click += new System.EventHandler(this.button_displayImage_Click);
            // 
            // trackBar_angle
            // 
            this.trackBar_angle.BackColor = System.Drawing.SystemColors.Control;
            this.trackBar_angle.LargeChange = 1;
            this.trackBar_angle.Location = new System.Drawing.Point(108, 60);
            this.trackBar_angle.Maximum = 360;
            this.trackBar_angle.Minimum = -360;
            this.trackBar_angle.Name = "trackBar_angle";
            this.trackBar_angle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_angle.Size = new System.Drawing.Size(367, 45);
            this.trackBar_angle.TabIndex = 9;
            this.trackBar_angle.Scroll += new System.EventHandler(this.trackBar_rotate_Scroll);
            // 
            // label_angle
            // 
            this.label_angle.AutoSize = true;
            this.label_angle.Location = new System.Drawing.Point(477, 60);
            this.label_angle.Name = "label_angle";
            this.label_angle.Size = new System.Drawing.Size(25, 20);
            this.label_angle.TabIndex = 10;
            this.label_angle.Text = "0°";
            // 
            // button_MirrorLeftandRight
            // 
            this.button_MirrorLeftandRight.Location = new System.Drawing.Point(581, 42);
            this.button_MirrorLeftandRight.Name = "button_MirrorLeftandRight";
            this.button_MirrorLeftandRight.Size = new System.Drawing.Size(94, 29);
            this.button_MirrorLeftandRight.TabIndex = 12;
            this.button_MirrorLeftandRight.Text = "水平翻轉";
            this.button_MirrorLeftandRight.UseVisualStyleBackColor = true;
            this.button_MirrorLeftandRight.Click += new System.EventHandler(this.button_MirrorLeftandRight_Click);
            // 
            // button_MirrorUpandDown
            // 
            this.button_MirrorUpandDown.Location = new System.Drawing.Point(581, 77);
            this.button_MirrorUpandDown.Name = "button_MirrorUpandDown";
            this.button_MirrorUpandDown.Size = new System.Drawing.Size(94, 29);
            this.button_MirrorUpandDown.TabIndex = 13;
            this.button_MirrorUpandDown.Text = "垂直翻轉";
            this.button_MirrorUpandDown.UseVisualStyleBackColor = true;
            this.button_MirrorUpandDown.Click += new System.EventHandler(this.button_MirrorUpandDown_Click);
            // 
            // button_MirroringUpDownLeftandRight
            // 
            this.button_MirroringUpDownLeftandRight.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_MirroringUpDownLeftandRight.Location = new System.Drawing.Point(581, 112);
            this.button_MirroringUpDownLeftandRight.Name = "button_MirroringUpDownLeftandRight";
            this.button_MirroringUpDownLeftandRight.Size = new System.Drawing.Size(94, 29);
            this.button_MirroringUpDownLeftandRight.TabIndex = 14;
            this.button_MirroringUpDownLeftandRight.Text = "水平垂直";
            this.button_MirroringUpDownLeftandRight.UseVisualStyleBackColor = true;
            this.button_MirroringUpDownLeftandRight.Click += new System.EventHandler(this.button_MirroringUpDownLeftandRight_Click);
            // 
            // trackBar_x
            // 
            this.trackBar_x.LargeChange = 1;
            this.trackBar_x.Location = new System.Drawing.Point(108, 105);
            this.trackBar_x.Maximum = 500;
            this.trackBar_x.Minimum = 1;
            this.trackBar_x.Name = "trackBar_x";
            this.trackBar_x.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_x.Size = new System.Drawing.Size(367, 45);
            this.trackBar_x.TabIndex = 15;
            this.trackBar_x.Value = 100;
            this.trackBar_x.Scroll += new System.EventHandler(this.trackBar_x_Scroll);
            // 
            // label_x
            // 
            this.label_x.AutoSize = true;
            this.label_x.Location = new System.Drawing.Point(477, 105);
            this.label_x.Name = "label_x";
            this.label_x.Size = new System.Drawing.Size(48, 20);
            this.label_x.TabIndex = 18;
            this.label_x.Text = "X × 1";
            // 
            // label_y
            // 
            this.label_y.AutoSize = true;
            this.label_y.Location = new System.Drawing.Point(477, 151);
            this.label_y.Name = "label_y";
            this.label_y.Size = new System.Drawing.Size(48, 20);
            this.label_y.TabIndex = 19;
            this.label_y.Text = "Y × 1";
            // 
            // trackBar_y
            // 
            this.trackBar_y.LargeChange = 1;
            this.trackBar_y.Location = new System.Drawing.Point(108, 151);
            this.trackBar_y.Maximum = 500;
            this.trackBar_y.Minimum = 1;
            this.trackBar_y.Name = "trackBar_y";
            this.trackBar_y.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_y.Size = new System.Drawing.Size(367, 45);
            this.trackBar_y.TabIndex = 20;
            this.trackBar_y.Value = 100;
            this.trackBar_y.Scroll += new System.EventHandler(this.trackBar_Y_Scroll);
            // 
            // trackBar_ShearH
            // 
            this.trackBar_ShearH.LargeChange = 1;
            this.trackBar_ShearH.Location = new System.Drawing.Point(108, 202);
            this.trackBar_ShearH.Maximum = 500;
            this.trackBar_ShearH.Minimum = -500;
            this.trackBar_ShearH.Name = "trackBar_ShearH";
            this.trackBar_ShearH.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_ShearH.Size = new System.Drawing.Size(367, 45);
            this.trackBar_ShearH.TabIndex = 22;
            this.trackBar_ShearH.Scroll += new System.EventHandler(this.trackBar_ShearH_Scroll);
            // 
            // trackBar_ShearV
            // 
            this.trackBar_ShearV.LargeChange = 1;
            this.trackBar_ShearV.Location = new System.Drawing.Point(108, 253);
            this.trackBar_ShearV.Maximum = 500;
            this.trackBar_ShearV.Minimum = -500;
            this.trackBar_ShearV.Name = "trackBar_ShearV";
            this.trackBar_ShearV.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_ShearV.Size = new System.Drawing.Size(367, 45);
            this.trackBar_ShearV.TabIndex = 23;
            this.trackBar_ShearV.Scroll += new System.EventHandler(this.trackBar_ShearV_Scroll);
            // 
            // label_ShearH
            // 
            this.label_ShearH.AutoSize = true;
            this.label_ShearH.Location = new System.Drawing.Point(477, 202);
            this.label_ShearH.Name = "label_ShearH";
            this.label_ShearH.Size = new System.Drawing.Size(57, 20);
            this.label_ShearH.TabIndex = 26;
            this.label_ShearH.Text = "Sh = 0";
            // 
            // label_ShearV
            // 
            this.label_ShearV.AutoSize = true;
            this.label_ShearV.Location = new System.Drawing.Point(477, 253);
            this.label_ShearV.Name = "label_ShearV";
            this.label_ShearV.Size = new System.Drawing.Size(55, 20);
            this.label_ShearV.TabIndex = 27;
            this.label_ShearV.Text = "Sv = 0";
            // 
            // trackBar_FlipX
            // 
            this.trackBar_FlipX.LargeChange = 1;
            this.trackBar_FlipX.Location = new System.Drawing.Point(108, 304);
            this.trackBar_FlipX.Maximum = 100;
            this.trackBar_FlipX.Minimum = -100;
            this.trackBar_FlipX.Name = "trackBar_FlipX";
            this.trackBar_FlipX.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_FlipX.Size = new System.Drawing.Size(367, 45);
            this.trackBar_FlipX.TabIndex = 29;
            this.trackBar_FlipX.Value = 100;
            this.trackBar_FlipX.Scroll += new System.EventHandler(this.trackBar_FlipX_Scroll);
            // 
            // trackBar_FlipY
            // 
            this.trackBar_FlipY.LargeChange = 1;
            this.trackBar_FlipY.Location = new System.Drawing.Point(108, 355);
            this.trackBar_FlipY.Maximum = 100;
            this.trackBar_FlipY.Minimum = -100;
            this.trackBar_FlipY.Name = "trackBar_FlipY";
            this.trackBar_FlipY.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_FlipY.Size = new System.Drawing.Size(367, 45);
            this.trackBar_FlipY.TabIndex = 30;
            this.trackBar_FlipY.Value = 100;
            this.trackBar_FlipY.Scroll += new System.EventHandler(this.trackBar_FlipY_Scroll);
            // 
            // label_FlipX
            // 
            this.label_FlipX.AutoSize = true;
            this.label_FlipX.Location = new System.Drawing.Point(477, 301);
            this.label_FlipX.Name = "label_FlipX";
            this.label_FlipX.Size = new System.Drawing.Size(48, 20);
            this.label_FlipX.TabIndex = 32;
            this.label_FlipX.Text = "X × 1";
            // 
            // label_FlipY
            // 
            this.label_FlipY.AutoSize = true;
            this.label_FlipY.Location = new System.Drawing.Point(477, 355);
            this.label_FlipY.Name = "label_FlipY";
            this.label_FlipY.Size = new System.Drawing.Size(48, 20);
            this.label_FlipY.TabIndex = 33;
            this.label_FlipY.Text = "Y × 1";
            // 
            // button_grayscaleImage
            // 
            this.button_grayscaleImage.Location = new System.Drawing.Point(581, 147);
            this.button_grayscaleImage.Name = "button_grayscaleImage";
            this.button_grayscaleImage.Size = new System.Drawing.Size(94, 29);
            this.button_grayscaleImage.TabIndex = 34;
            this.button_grayscaleImage.Text = "灰階";
            this.button_grayscaleImage.UseVisualStyleBackColor = true;
            this.button_grayscaleImage.Click += new System.EventHandler(this.button_grayscaleImage_Click);
            // 
            // trackBar_Vague
            // 
            this.trackBar_Vague.LargeChange = 1;
            this.trackBar_Vague.Location = new System.Drawing.Point(108, 406);
            this.trackBar_Vague.Maximum = 150;
            this.trackBar_Vague.Minimum = 1;
            this.trackBar_Vague.Name = "trackBar_Vague";
            this.trackBar_Vague.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_Vague.Size = new System.Drawing.Size(367, 45);
            this.trackBar_Vague.TabIndex = 36;
            this.trackBar_Vague.Value = 1;
            this.trackBar_Vague.Scroll += new System.EventHandler(this.trackBar_Vague_Scroll);
            // 
            // label_Vague
            // 
            this.label_Vague.AutoSize = true;
            this.label_Vague.Location = new System.Drawing.Point(477, 406);
            this.label_Vague.Name = "label_Vague";
            this.label_Vague.Size = new System.Drawing.Size(62, 20);
            this.label_Vague.TabIndex = 37;
            this.label_Vague.Text = "MS = 1";
            // 
            // button_Negative
            // 
            this.button_Negative.Location = new System.Drawing.Point(581, 182);
            this.button_Negative.Name = "button_Negative";
            this.button_Negative.Size = new System.Drawing.Size(94, 29);
            this.button_Negative.TabIndex = 39;
            this.button_Negative.Text = "負片";
            this.button_Negative.UseVisualStyleBackColor = true;
            this.button_Negative.Click += new System.EventHandler(this.button_Negative_Click);
            // 
            // trackBar_Log
            // 
            this.trackBar_Log.LargeChange = 1;
            this.trackBar_Log.Location = new System.Drawing.Point(108, 457);
            this.trackBar_Log.Maximum = 200;
            this.trackBar_Log.Name = "trackBar_Log";
            this.trackBar_Log.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_Log.Size = new System.Drawing.Size(367, 45);
            this.trackBar_Log.TabIndex = 42;
            this.trackBar_Log.Value = 100;
            this.trackBar_Log.Scroll += new System.EventHandler(this.trackBar_Log_Scroll);
            // 
            // label_Log
            // 
            this.label_Log.AutoSize = true;
            this.label_Log.Location = new System.Drawing.Point(477, 457);
            this.label_Log.Name = "label_Log";
            this.label_Log.Size = new System.Drawing.Size(66, 20);
            this.label_Log.TabIndex = 43;
            this.label_Log.Text = "Log = 1";
            // 
            // trackBar_PowerLaw
            // 
            this.trackBar_PowerLaw.LargeChange = 1;
            this.trackBar_PowerLaw.Location = new System.Drawing.Point(108, 508);
            this.trackBar_PowerLaw.Maximum = 1000;
            this.trackBar_PowerLaw.Name = "trackBar_PowerLaw";
            this.trackBar_PowerLaw.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_PowerLaw.Size = new System.Drawing.Size(367, 45);
            this.trackBar_PowerLaw.TabIndex = 44;
            this.trackBar_PowerLaw.Value = 100;
            this.trackBar_PowerLaw.Scroll += new System.EventHandler(this.trackBar_PowerLaw_Scroll);
            // 
            // label_PowerGamma
            // 
            this.label_PowerGamma.AutoSize = true;
            this.label_PowerGamma.Location = new System.Drawing.Point(477, 508);
            this.label_PowerGamma.Name = "label_PowerGamma";
            this.label_PowerGamma.Size = new System.Drawing.Size(47, 20);
            this.label_PowerGamma.TabIndex = 45;
            this.label_PowerGamma.Text = "γ = 1";
            // 
            // button_Rotate
            // 
            this.button_Rotate.Location = new System.Drawing.Point(12, 60);
            this.button_Rotate.Name = "button_Rotate";
            this.button_Rotate.Size = new System.Drawing.Size(94, 29);
            this.button_Rotate.TabIndex = 47;
            this.button_Rotate.Text = "旋轉";
            this.button_Rotate.UseVisualStyleBackColor = true;
            this.button_Rotate.Click += new System.EventHandler(this.button_Rotate_Click);
            // 
            // button_Zoom
            // 
            this.button_Zoom.Location = new System.Drawing.Point(12, 132);
            this.button_Zoom.Name = "button_Zoom";
            this.button_Zoom.Size = new System.Drawing.Size(94, 29);
            this.button_Zoom.TabIndex = 48;
            this.button_Zoom.Text = "縮放";
            this.button_Zoom.UseVisualStyleBackColor = true;
            this.button_Zoom.Click += new System.EventHandler(this.button_Zoom_Click);
            // 
            // button_Shear
            // 
            this.button_Shear.Location = new System.Drawing.Point(12, 230);
            this.button_Shear.Name = "button_Shear";
            this.button_Shear.Size = new System.Drawing.Size(94, 29);
            this.button_Shear.TabIndex = 49;
            this.button_Shear.Text = "剪形";
            this.button_Shear.UseVisualStyleBackColor = true;
            this.button_Shear.Click += new System.EventHandler(this.button_Shear_Click);
            // 
            // button_Flip
            // 
            this.button_Flip.Location = new System.Drawing.Point(12, 332);
            this.button_Flip.Name = "button_Flip";
            this.button_Flip.Size = new System.Drawing.Size(94, 29);
            this.button_Flip.TabIndex = 50;
            this.button_Flip.Text = "翻轉";
            this.button_Flip.UseVisualStyleBackColor = true;
            this.button_Flip.Click += new System.EventHandler(this.button_Flip_Click);
            // 
            // button_Vague
            // 
            this.button_Vague.Location = new System.Drawing.Point(12, 406);
            this.button_Vague.Name = "button_Vague";
            this.button_Vague.Size = new System.Drawing.Size(94, 29);
            this.button_Vague.TabIndex = 51;
            this.button_Vague.Text = "模糊";
            this.button_Vague.UseVisualStyleBackColor = true;
            this.button_Vague.Click += new System.EventHandler(this.button_Vague_Click);
            // 
            // button_Log
            // 
            this.button_Log.Location = new System.Drawing.Point(12, 457);
            this.button_Log.Name = "button_Log";
            this.button_Log.Size = new System.Drawing.Size(94, 29);
            this.button_Log.TabIndex = 52;
            this.button_Log.Text = "Log亮度";
            this.button_Log.UseVisualStyleBackColor = true;
            this.button_Log.Click += new System.EventHandler(this.button_Log_Click);
            // 
            // button_PowerLaw
            // 
            this.button_PowerLaw.Location = new System.Drawing.Point(12, 508);
            this.button_PowerLaw.Name = "button_PowerLaw";
            this.button_PowerLaw.Size = new System.Drawing.Size(94, 29);
            this.button_PowerLaw.TabIndex = 53;
            this.button_PowerLaw.Text = "PowerLaw";
            this.button_PowerLaw.UseVisualStyleBackColor = true;
            this.button_PowerLaw.Click += new System.EventHandler(this.button_PowerLaw_Click);
            // 
            // trackBar_Saturation
            // 
            this.trackBar_Saturation.LargeChange = 1;
            this.trackBar_Saturation.Location = new System.Drawing.Point(108, 661);
            this.trackBar_Saturation.Maximum = 300;
            this.trackBar_Saturation.Name = "trackBar_Saturation";
            this.trackBar_Saturation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_Saturation.Size = new System.Drawing.Size(367, 45);
            this.trackBar_Saturation.TabIndex = 54;
            this.trackBar_Saturation.Value = 100;
            this.trackBar_Saturation.Scroll += new System.EventHandler(this.trackBar_Saturation_Scroll);
            // 
            // label_Saturation
            // 
            this.label_Saturation.AutoSize = true;
            this.label_Saturation.Location = new System.Drawing.Point(477, 661);
            this.label_Saturation.Name = "label_Saturation";
            this.label_Saturation.Size = new System.Drawing.Size(65, 20);
            this.label_Saturation.TabIndex = 55;
            this.label_Saturation.Text = "Pos = 1";
            // 
            // button_Saturation
            // 
            this.button_Saturation.Location = new System.Drawing.Point(12, 661);
            this.button_Saturation.Name = "button_Saturation";
            this.button_Saturation.Size = new System.Drawing.Size(94, 29);
            this.button_Saturation.TabIndex = 56;
            this.button_Saturation.Text = "飽和度";
            this.button_Saturation.UseVisualStyleBackColor = true;
            this.button_Saturation.Click += new System.EventHandler(this.button_Saturation_Click);
            // 
            // button_CloseAllWindows
            // 
            this.button_CloseAllWindows.Location = new System.Drawing.Point(581, 712);
            this.button_CloseAllWindows.Name = "button_CloseAllWindows";
            this.button_CloseAllWindows.Size = new System.Drawing.Size(94, 29);
            this.button_CloseAllWindows.TabIndex = 57;
            this.button_CloseAllWindows.Text = "關閉視窗";
            this.button_CloseAllWindows.UseVisualStyleBackColor = true;
            this.button_CloseAllWindows.Click += new System.EventHandler(this.button_CloseAllWindows_Click);
            // 
            // trackBar_Laplace
            // 
            this.trackBar_Laplace.LargeChange = 1;
            this.trackBar_Laplace.Location = new System.Drawing.Point(108, 712);
            this.trackBar_Laplace.Name = "trackBar_Laplace";
            this.trackBar_Laplace.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_Laplace.Size = new System.Drawing.Size(367, 45);
            this.trackBar_Laplace.TabIndex = 58;
            this.trackBar_Laplace.Scroll += new System.EventHandler(this.trackBar_Laplace_Scroll);
            // 
            // label_Laplace
            // 
            this.label_Laplace.AutoSize = true;
            this.label_Laplace.Location = new System.Drawing.Point(477, 712);
            this.label_Laplace.Name = "label_Laplace";
            this.label_Laplace.Size = new System.Drawing.Size(48, 20);
            this.label_Laplace.TabIndex = 59;
            this.label_Laplace.Text = "X = 0";
            // 
            // button_Laplace
            // 
            this.button_Laplace.Location = new System.Drawing.Point(12, 712);
            this.button_Laplace.Name = "button_Laplace";
            this.button_Laplace.Size = new System.Drawing.Size(94, 29);
            this.button_Laplace.TabIndex = 60;
            this.button_Laplace.Text = "銳利度";
            this.button_Laplace.UseVisualStyleBackColor = true;
            this.button_Laplace.Click += new System.EventHandler(this.button_Laplace_Click);
            // 
            // trackBar_alpha
            // 
            this.trackBar_alpha.LargeChange = 1;
            this.trackBar_alpha.Location = new System.Drawing.Point(108, 559);
            this.trackBar_alpha.Maximum = 1000;
            this.trackBar_alpha.Name = "trackBar_alpha";
            this.trackBar_alpha.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_alpha.Size = new System.Drawing.Size(367, 45);
            this.trackBar_alpha.TabIndex = 61;
            this.trackBar_alpha.Value = 100;
            this.trackBar_alpha.Scroll += new System.EventHandler(this.trackBar_alpha_Scroll);
            // 
            // trackBar_beta
            // 
            this.trackBar_beta.LargeChange = 1;
            this.trackBar_beta.Location = new System.Drawing.Point(108, 610);
            this.trackBar_beta.Maximum = 255;
            this.trackBar_beta.Minimum = -255;
            this.trackBar_beta.Name = "trackBar_beta";
            this.trackBar_beta.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar_beta.Size = new System.Drawing.Size(367, 45);
            this.trackBar_beta.TabIndex = 62;
            this.trackBar_beta.Scroll += new System.EventHandler(this.trackBar_beta_Scroll);
            // 
            // label_alpha
            // 
            this.label_alpha.AutoSize = true;
            this.label_alpha.Location = new System.Drawing.Point(477, 559);
            this.label_alpha.Name = "label_alpha";
            this.label_alpha.Size = new System.Drawing.Size(49, 20);
            this.label_alpha.TabIndex = 63;
            this.label_alpha.Text = "α = 1";
            // 
            // label_beta
            // 
            this.label_beta.AutoSize = true;
            this.label_beta.Location = new System.Drawing.Point(477, 610);
            this.label_beta.Name = "label_beta";
            this.label_beta.Size = new System.Drawing.Size(47, 20);
            this.label_beta.TabIndex = 64;
            this.label_beta.Text = "β = 0";
            // 
            // button_ConvertScaleAbs
            // 
            this.button_ConvertScaleAbs.Location = new System.Drawing.Point(12, 586);
            this.button_ConvertScaleAbs.Name = "button_ConvertScaleAbs";
            this.button_ConvertScaleAbs.Size = new System.Drawing.Size(94, 29);
            this.button_ConvertScaleAbs.TabIndex = 65;
            this.button_ConvertScaleAbs.Text = "線性亮度";
            this.button_ConvertScaleAbs.UseVisualStyleBackColor = true;
            this.button_ConvertScaleAbs.Click += new System.EventHandler(this.button_ConvertScaleAbs_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(690, 768);
            this.Controls.Add(this.button_ConvertScaleAbs);
            this.Controls.Add(this.label_beta);
            this.Controls.Add(this.label_alpha);
            this.Controls.Add(this.trackBar_beta);
            this.Controls.Add(this.trackBar_alpha);
            this.Controls.Add(this.button_Laplace);
            this.Controls.Add(this.label_Laplace);
            this.Controls.Add(this.trackBar_Laplace);
            this.Controls.Add(this.button_CloseAllWindows);
            this.Controls.Add(this.button_Saturation);
            this.Controls.Add(this.label_Saturation);
            this.Controls.Add(this.trackBar_Saturation);
            this.Controls.Add(this.button_PowerLaw);
            this.Controls.Add(this.button_Log);
            this.Controls.Add(this.button_Vague);
            this.Controls.Add(this.button_Flip);
            this.Controls.Add(this.button_Shear);
            this.Controls.Add(this.button_Zoom);
            this.Controls.Add(this.button_Rotate);
            this.Controls.Add(this.label_PowerGamma);
            this.Controls.Add(this.trackBar_PowerLaw);
            this.Controls.Add(this.label_Log);
            this.Controls.Add(this.trackBar_Log);
            this.Controls.Add(this.button_Negative);
            this.Controls.Add(this.label_Vague);
            this.Controls.Add(this.trackBar_Vague);
            this.Controls.Add(this.button_grayscaleImage);
            this.Controls.Add(this.label_FlipY);
            this.Controls.Add(this.label_FlipX);
            this.Controls.Add(this.trackBar_FlipY);
            this.Controls.Add(this.trackBar_FlipX);
            this.Controls.Add(this.label_ShearV);
            this.Controls.Add(this.label_ShearH);
            this.Controls.Add(this.trackBar_ShearV);
            this.Controls.Add(this.trackBar_ShearH);
            this.Controls.Add(this.trackBar_y);
            this.Controls.Add(this.label_y);
            this.Controls.Add(this.label_x);
            this.Controls.Add(this.trackBar_x);
            this.Controls.Add(this.button_MirroringUpDownLeftandRight);
            this.Controls.Add(this.button_MirrorUpandDown);
            this.Controls.Add(this.button_MirrorLeftandRight);
            this.Controls.Add(this.label_angle);
            this.Controls.Add(this.trackBar_angle);
            this.Controls.Add(this.displayImage);
            this.Controls.Add(this.textBox_fileName);
            this.Controls.Add(this.label_fileName);
            this.Controls.Add(this.selectFile);
            this.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "影像處理";
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_angle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_ShearH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_ShearV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_FlipX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_FlipY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Vague)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Log)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_PowerLaw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Saturation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Laplace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_alpha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_beta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button selectFile;
        private System.Windows.Forms.Label label_fileName;
        private System.Windows.Forms.TextBox textBox_fileName;
        private System.Windows.Forms.Button displayImage;
        private System.Windows.Forms.TrackBar trackBar_angle;
        private System.Windows.Forms.Label label_angle;
        private System.Windows.Forms.Button button_MirrorLeftandRight;
        private System.Windows.Forms.Button button_MirrorUpandDown;
        private System.Windows.Forms.Button button_MirroringUpDownLeftandRight;
        private System.Windows.Forms.TrackBar trackBar_x;
        private System.Windows.Forms.Label label_x;
        private System.Windows.Forms.Label label_y;
        private System.Windows.Forms.TrackBar trackBar_y;
        private System.Windows.Forms.TrackBar trackBar_ShearH;
        private System.Windows.Forms.TrackBar trackBar_ShearV;
        private System.Windows.Forms.Label label_ShearH;
        private System.Windows.Forms.Label label_ShearV;
        private System.Windows.Forms.TrackBar trackBar_FlipX;
        private System.Windows.Forms.TrackBar trackBar_FlipY;
        private System.Windows.Forms.Label label_FlipX;
        private System.Windows.Forms.Label label_FlipY;
        private System.Windows.Forms.Button button_grayscaleImage;
        private System.Windows.Forms.TrackBar trackBar_Vague;
        private System.Windows.Forms.Label label_Vague;
        private System.Windows.Forms.Button button_Negative;
        private System.Windows.Forms.TrackBar trackBar_Log;
        private System.Windows.Forms.Label label_Log;
        private System.Windows.Forms.TrackBar trackBar_PowerLaw;
        private System.Windows.Forms.Label label_PowerGamma;
        private System.Windows.Forms.Button button_Rotate;
        private System.Windows.Forms.Button button_Zoom;
        private System.Windows.Forms.Button button_Shear;
        private System.Windows.Forms.Button button_Flip;
        private System.Windows.Forms.Button button_Vague;
        private System.Windows.Forms.Button button_Log;
        private System.Windows.Forms.Button button_PowerLaw;
        private System.Windows.Forms.TrackBar trackBar_Saturation;
        private System.Windows.Forms.Label label_Saturation;
        private System.Windows.Forms.Button button_Saturation;
        private System.Windows.Forms.Button button_CloseAllWindows;
        private System.Windows.Forms.TrackBar trackBar_Laplace;
        private System.Windows.Forms.Label label_Laplace;
        private System.Windows.Forms.Button button_Laplace;
        private System.Windows.Forms.TrackBar trackBar_alpha;
        private System.Windows.Forms.TrackBar trackBar_beta;
        private System.Windows.Forms.Label label_alpha;
        private System.Windows.Forms.Label label_beta;
        private System.Windows.Forms.Button button_ConvertScaleAbs;
    }
}

