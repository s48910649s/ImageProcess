#pragma once
//�K�K�K�K�K�K�K�K�K�K�K�K�K�K�K�K�K�K
#ifdef IMGFUNC_EXPORTS
#define IMGFUNC_API extern "C" __declspec(dllexport)
#else
#define IMGFUNC_API extern "C" __declspec(dllimport)
#endif
IMGFUNC_API void showImage(char* filename);
IMGFUNC_API void showGrayscaleImage(char* filename);
IMGFUNC_API void myRotate(char* filename, double angle);
IMGFUNC_API void myMirrorLeftandRight(char* filename);
IMGFUNC_API void myMirrorUpandDown(char* filename);
IMGFUNC_API void myMirroringUpDownLeftandRight(char* filename);
IMGFUNC_API void myZoom(char* filename, double fx, double fy);
IMGFUNC_API void myShear(char* filename, double Sh, double Sv);
IMGFUNC_API void myFlip(char* filename, double x, double y);
IMGFUNC_API void myVague(char* filename, int maskSize);
IMGFUNC_API void myNegative(char* filename);
IMGFUNC_API void myLog(char* filename, double L);
IMGFUNC_API void myPowerLaw(char* filename, double powerGamma);
IMGFUNC_API void mySaturation(char* filename, double pos);
IMGFUNC_API void myLaplace(char* filename, int x);
IMGFUNC_API void myConvertScaleAbs(char* filename, double alpha, double beta);
IMGFUNC_API void myCloseAllWindows();