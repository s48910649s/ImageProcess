#include "pch.h"
#include "imgFunc.h"
#include <iostream>
#include <opencv2/opencv.hpp>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
using namespace cv;
using namespace std;

IMGFUNC_API void showImage(char* filename) //��ܱm����
{
	Mat src = imread(filename, IMREAD_REDUCED_COLOR_2);
	if (!src.empty()) {
        namedWindow("�m��");
        moveWindow("�m��", 700, 0);
		imshow("�m��", src);
	}
}

IMGFUNC_API void myMirrorLeftandRight(char* filename) { //����½��
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        Mat dstImg;
        Mat M = (Mat_<double>(2, 3) << -1, 0, img.cols, 0, 1, 0);
        warpAffine(img, dstImg, M, img.size());
        namedWindow("����½��");
        moveWindow("����½��", 1214, 0);
        imshow("����½��", dstImg);
    }
}

IMGFUNC_API void myMirrorUpandDown(char* filename) { //����½��
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        Mat dstImg;
        Mat M = (Mat_<double>(2, 3) << 1, 0, 0, 0, -1, img.rows);
        warpAffine(img, dstImg, M, img.size());
        namedWindow("����½��");
        moveWindow("����½��", 700, 416);
        imshow("����½��", dstImg);
    }
}

IMGFUNC_API void myMirroringUpDownLeftandRight(char* filename) { //����½��
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        Mat dstImg;
        Mat M = (Mat_<double>(2, 3) << -1, 0, img.cols, 0, -1, img.rows);
        warpAffine(img, dstImg, M, img.size());
        namedWindow("��������½��");
        moveWindow("��������½��", 1214, 416);
        imshow("��������½��", dstImg);
    }
}

IMGFUNC_API void showGrayscaleImage(char* filename) //��ܦǶ����
{
    Mat src = imread(filename, IMREAD_REDUCED_GRAYSCALE_2);
    if (!src.empty()) {
        namedWindow("�Ƕ�");
        moveWindow("�Ƕ�", 700, 0);
        imshow("�Ƕ�", src);
    }
}

IMGFUNC_API void myNegative(char* filename) { //�t��
    Mat img = imread(filename, IMREAD_REDUCED_GRAYSCALE_2);
    if (!img.empty()) {
        img = 255 - img;
        namedWindow("�t��");
        moveWindow("�t��", 1214, 0);
        imshow("�t��", img);
    }
}

IMGFUNC_API void myRotate(char* filename, double angle) { //����
	Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
	if (!img.empty()) {
		Mat dstImg;
		double alpha = 3.14159 * angle / 180.0;
        Point2f srcP[3];
        Point2f dstP[3];
        srcP[0] = Point2f(0, img.rows);
        srcP[1] = Point2f(img.cols, 0);
        srcP[2] = Point2f(img.cols, img.rows);
        for (int i = 0; i < 3; i++) dstP[i] = Point2f(srcP[i].x * cos(alpha) - srcP[i].y * sin(alpha), srcP[i].y * cos(alpha) + srcP[i].x * sin(alpha)); //rotate the pixels
        double minx, miny, maxx, maxy;
        minx = min(min(min(dstP[0].x, dstP[1].x), dstP[2].x), float(0.0));
        miny = min(min(min(dstP[0].y, dstP[1].y), dstP[2].y), float(0.0));
        maxx = max(max(max(dstP[0].x, dstP[1].x), dstP[2].x), float(0.0));
        maxy = max(max(max(dstP[0].y, dstP[1].y), dstP[2].y), float(0.0));
        int w = maxx - minx;
        int h = maxy - miny;
        for (int i = 0; i < 3; i++) //translation
        {
            if (minx < 0) dstP[i].x -= minx;
            if (miny < 0) dstP[i].y -= miny;
        }
        Mat warpMat = getAffineTransform(srcP, dstP);
        warpAffine(img, dstImg, warpMat, Size(w, h));
        namedWindow("����");
        moveWindow("����", 700, 0);
		imshow("����", dstImg);
	}
}

IMGFUNC_API void myZoom(char* filename, double fx, double fy) { //�Y��
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        resize(img, img, Size(), fx, fy, INTER_LINEAR);
        namedWindow("�Y��");
        moveWindow("�Y��", 700, 0);
        imshow("�Y��", img);
    }
}

IMGFUNC_API void myShear(char* filename, double Sh, double Sv) { //�ŧ�
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        Mat dstImg;
        Point2f srcP[3];
        Point2f dstP[3];
        srcP[0] = Point2f(0, img.rows);
        srcP[1] = Point2f(img.cols, 0);
        srcP[2] = Point2f(img.cols, img.rows);
        for (int i = 0; i < 3; i++) dstP[i] = Point2f(srcP[i].x * 1 + srcP[i].y * Sh, srcP[i].x * Sv + srcP[i].y * 1);
        double minx, miny, maxx, maxy;
        minx = min(min(min(dstP[0].x, dstP[1].x), dstP[2].x), float(0.0));
        miny = min(min(min(dstP[0].y, dstP[1].y), dstP[2].y), float(0.0));
        maxx = max(max(max(dstP[0].x, dstP[1].x), dstP[2].x), float(0.0));
        maxy = max(max(max(dstP[0].y, dstP[1].y), dstP[2].y), float(0.0));
        int w = maxx - minx;
        int h = maxy - miny;
        for (int i = 0; i < 3; i++)
        {
            if (minx < 0) dstP[i].x -= minx;
            if (miny < 0) dstP[i].y -= miny;
        }
        Mat warpMat = getAffineTransform(srcP, dstP);
        warpAffine(img, dstImg, warpMat, Size(w, h));
        namedWindow("�ŧ�");
        moveWindow("�ŧ�", 700, 0);
        imshow("�ŧ�", dstImg);
    }
}

IMGFUNC_API void myFlip(char* filename, double x, double y) { //½��
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        Mat dstImg;
        Point2f srcP[3];
        Point2f dstP[3];
        srcP[0] = Point2f(0, img.rows);
        srcP[1] = Point2f(img.cols, 0);
        srcP[2] = Point2f(img.cols, img.rows);
        for (int i = 0; i < 3; i++) dstP[i] = Point2f(srcP[i].x * x, srcP[i].y * y);
        double minx, miny, maxx, maxy;
        minx = min(min(min(dstP[0].x, dstP[1].x), dstP[2].x), float(0.0));
        miny = min(min(min(dstP[0].y, dstP[1].y), dstP[2].y), float(0.0));
        maxx = max(max(max(dstP[0].x, dstP[1].x), dstP[2].x), float(0.0));
        maxy = max(max(max(dstP[0].y, dstP[1].y), dstP[2].y), float(0.0));
        int w = maxx - minx;
        int h = maxy - miny;
        for (int i = 0; i < 3; i++)
        {
            if (minx < 0) dstP[i].x -= minx;
            if (miny < 0) dstP[i].y -= miny;
        }
        Mat warpMat = getAffineTransform(srcP, dstP);
        warpAffine(img, dstImg, warpMat, Size(w, h));
        namedWindow("½��");
        moveWindow("½��", 700, 0);
        imshow("½��", dstImg);
    }
}

IMGFUNC_API void myVague(char* filename, int maskSize) { //�ҽk
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2), dst;
    if (!img.empty()) {
        Mat mask = Mat::ones(maskSize, maskSize, CV_32F) / (float)(maskSize * maskSize);
        filter2D(img, dst, img.depth(), mask, Point(maskSize / 2, maskSize / 2));
        namedWindow("�ҽk");
        moveWindow("�ҽk", 700, 0);
        imshow("�ҽk", dst);
    }
}

IMGFUNC_API void myLog(char* filename, double L) { //Log�G��
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        img.convertTo(img, CV_32F, 1.f / 255.f, 0);
        log((img + L) * 1.000000000000001, img);
        img /= log(2.0);
        namedWindow("Log�G��");
        moveWindow("Log�G��", 700, 0);
        imshow("Log�G��", img);
    }
}

IMGFUNC_API void myPowerLaw(char* filename, double PowerGamma) { //PowerLaw�G��
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        img.convertTo(img, CV_32F, 1.f / 255.f, 0);
        pow(img, PowerGamma, img);
        namedWindow("PowerLaw�G��");
        moveWindow("PowerLaw�G��", 1214, 0);
        imshow("PowerLaw�G��", img);
    }
}

IMGFUNC_API void mySaturation(char* filename, double pos) { //���M��  
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        Mat hsv, hsvPlanes[3], rlt;
        cvtColor(img, hsv, COLOR_BGR2HSV);
        split(hsv, hsvPlanes);
        hsvPlanes[1] *= pos;
        merge(hsvPlanes, 3, hsv);
        cvtColor(hsv, rlt, COLOR_HSV2BGR);
        namedWindow("���M��");
        moveWindow("���M��", 700, 0);
        imshow("���M��", rlt);
    }
}

IMGFUNC_API void myLaplace(char* filename, int x) { //�U�Q��(Laplace���n)
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        Mat kernel = (Mat_<int>(3, 3) << 0, -x, 0, -x, 4 * x + 1, -x, 0, -x, 0);
        filter2D(img, img, img.depth(), kernel);
        namedWindow("�U�Q��");
        moveWindow("�U�Q��", 700, 0);
        imshow("�U�Q��", img);
    }
}

IMGFUNC_API void myConvertScaleAbs(char* filename, double alpha, double beta) { //�u�ʫG��
    Mat img = imread(filename, IMREAD_REDUCED_COLOR_2);
    if (!img.empty()) {
        convertScaleAbs(img, img, alpha, beta);
        namedWindow("�u�ʫG��");
        moveWindow("�u�ʫG��", 700, 416);
        imshow("�u�ʫG��", img);
    }
}

IMGFUNC_API void myCloseAllWindows() { //�����Ҧ�����
    destroyAllWindows();
}